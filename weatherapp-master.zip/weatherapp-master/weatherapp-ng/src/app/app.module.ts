import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes }   from '@angular/router';
import { SimpleNotificationsModule } from 'angular2-notifications';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { AppComponent } from './app.component';
import { SearchComponent } from './components/search/search.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { WeatherService } from './services/weather.service';
import { DateService } from './services/date.service';
import { WeatherdetailsComponent } from './components/weatherdetails/weatherdetails.component';


const appRoutes: Routes = [
 
  {
    path: '',
    component: WeatherdetailsComponent
  },
  {
    path: 'weather',
    component: WeatherdetailsComponent
  },
  {
    path: 'weather/:location',
    component: WeatherdetailsComponent
  }
];

@NgModule({
  declarations: [
    AppComponent,
    SearchComponent,
    NavbarComponent,
    WeatherdetailsComponent
  ],
  imports: [
    BrowserModule,
    HttpModule,
    FormsModule,
    BrowserAnimationsModule,
    SimpleNotificationsModule.forRoot(),
    RouterModule.forRoot(appRoutes)
  ],
  providers: [WeatherService,DateService],
  bootstrap: [AppComponent]
})

export class AppModule { }