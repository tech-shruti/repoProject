module.exports = {
  database: 'mongodb://localhost:27017/weatherapp',
  testdatabase: 'mongodb://localhost:27017/weatherapptest',
  secret: 'molokova'
}