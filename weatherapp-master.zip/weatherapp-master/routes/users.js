const express = require('express');
const router = express.Router();
const config = require('../config/database');
module.exports = router;