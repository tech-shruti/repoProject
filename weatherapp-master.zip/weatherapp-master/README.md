# weatherapp
A MEAN-stack weather application built with MongoDB, Express, Angular 4 and NodeJS and Open Weather Map REST services.


1) CD into 'weatherapp-master' root folder
2) Run 'npm install'
3) CD into Angular app 'weatherapp/weatherapp-ng'
4) Run 'npm install'
5) Run 'ng build' (prerequisite: Angular CLI tool)
6>Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

7) Run 'npm start' in root folder ('weatherapp')


